package com.carter.ffpanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private val channelId = "carter_ff_panel"
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("CART3R FF Panel ativo")
                .setContentText("Painel de referência flutuante")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("CART3R FF Panel ativo")
                .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        }
        startForeground(41, notification)
        showPanel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "CART3R Panel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(18, 10, 12))
        }
        val header = TextView(this).apply {
            text = "CART3R  •  FF TRAINING   [arraste aqui]"
            textSize = 14f
            setTextColor(Color.rgb(255, 65, 85))
            setPadding(dp(4), dp(6), dp(4), dp(12))
        }
        root.addView(header)
        val note = TextView(this).apply {
            text = "PAINEL DE TREINO — não interage com o jogo"
            textSize = 11f
            setTextColor(Color.LTGRAY)
        }
        root.addView(note)
        addSlider(root, "Sensibilidade geral (referência)", 0, 100, 70)
        addSlider(root, "Ponto vermelho (referência)", 0, 100, 55)
        addSlider(root, "Mira 2x (referência)", 0, 100, 60)
        addSlider(root, "Mira 4x (referência)", 0, 100, 45)
        val close = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener { stopSelf() }
        }
        root.addView(close)
        val params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(120) }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - touchX).toInt(); params.y = startY + (event.rawY - touchY).toInt(); windowManager.updateViewLayout(root, params); true }
                else -> true
            }
        }
        panel = root
        windowManager.addView(root, params)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
        val value = TextView(this).apply { text = "$label: $initial"; textSize = 12f; setTextColor(Color.WHITE) }
        val seek = SeekBar(this).apply { this.max = max - min; progress = initial - min }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) { value.text = "$label: ${progress + min}" }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        wrap.addView(value); wrap.addView(seek); parent.addView(wrap)
    }

    override fun onDestroy() {
        panel?.let { if (::windowManager.isInitialized) windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
