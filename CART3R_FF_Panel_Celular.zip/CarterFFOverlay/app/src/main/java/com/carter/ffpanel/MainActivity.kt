package com.carter.ffpanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF090909.toInt())
        }
        val title = TextView(this).apply {
            text = "CART3R FF PANEL"
            textSize = 26f
            setTextColor(0xFFFF334B.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Painel flutuante de referência para treino e ajustes.\nNão altera o Free Fire nem automatiza ações."
            textSize = 15f
            setTextColor(0xFFE0E0E0.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(24))
        }
        val start = Button(this).apply {
            text = "ATIVAR PAINEL FLUTUANTE"
            setOnClickListener { enableOverlay() }
        }
        val stop = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingPanelService::class.java)) }
        }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(info, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(start, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(stop, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, FloatingPanelService::class.java))
        else startService(Intent(this, FloatingPanelService::class.java))
    }
}
