# CART3R FF Panel (Android)

Projeto de painel flutuante de referência para Android. Ele não lê nem modifica a memória do Free Fire, não identifica adversários, não automatiza mira/tiros, não injeta código e não contorna proteções do jogo.

## Gerar o APK usando somente o celular (GitHub Actions)

1. Extraia o ZIP no ZArchiver.
2. No navegador do celular, entre em https://github.com e crie/acesse sua conta.
3. Crie um repositório novo (por exemplo, `cart3r-ff-panel`). Deixe-o como **Private** se preferir.
4. Envie os arquivos e pastas que estão dentro de `CarterFFOverlay` para a raiz do repositório. Inclua também a pasta oculta `.github/workflows` e o arquivo `build-apk.yml`.
5. Abra a aba **Actions** do repositório.
6. Se aparecer, confirme **I understand my workflows, go ahead and enable them**.
7. Selecione **Build CART3R FF Panel APK** e toque em **Run workflow**.
8. Aguarde a execução terminar com marca verde. Abra a execução e baixe o artefato `CART3R-FF-Panel-debug-apk`.
9. Extraia o ZIP do artefato e instale `app-debug.apk`. Se o Android pedir, permita a instalação dessa fonte para o navegador/gerenciador de arquivos.

## Usar o painel

1. Abra **CART3R FF Panel**.
2. Toque em **ATIVAR PAINEL FLUTUANTE** e conceda a permissão Android de exibir sobre outros apps.
3. Volte ao app e toque para ativar novamente, se necessário.
4. Arraste o painel pela barra superior. Use **FECHAR PAINEL** para fechar.

Os controles são apenas valores de referência: não alteram as configurações do jogo automaticamente. Digite manualmente no Free Fire qualquer ajuste que decidir usar.

## Build local

Android Studio recente, JDK 17 e Gradle 8.9; execute `gradle assembleDebug` na pasta do projeto.
